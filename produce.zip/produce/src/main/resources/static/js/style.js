function buttonClick(){
    document.getElementById('th1').removeAttribute('disabled')
    document.getElementById('th2').removeAttribute('disabled')
    document.getElementById('th3').removeAttribute('disabled')
    document.getElementById('th4').removeAttribute('disabled')
    document.getElementById('th5').removeAttribute('disabled')
    document.getElementById('th6').removeAttribute('disabled')
    document.getElementById('th7').removeAttribute('disabled')
    document.getElementById('th8').removeAttribute('disabled')
    document.getElementById('th9').removeAttribute('disabled')
    document.getElementById('th10').removeAttribute('disabled')
    document.getElementById("button1").disabled=false;
    document.getElementById('button').setAttribute('disabled', 'disabled');


}

function baocun() {
    document.getElementById('th1').setAttribute('disabled', 'disabled');
    document.getElementById('th2').setAttribute('disabled', 'disabled');
    document.getElementById('th3').setAttribute('disabled', 'disabled');
    document.getElementById('th4').setAttribute('disabled', 'disabled');
    document.getElementById('th5').setAttribute('disabled', 'disabled');
    document.getElementById('th6').setAttribute('disabled', 'disabled');
    document.getElementById('th7').setAttribute('disabled', 'disabled');
    document.getElementById('th8').setAttribute('disabled', 'disabled');
    document.getElementById('th9').setAttribute('disabled', 'disabled');
    document.getElementById('th10').setAttribute('disabled', 'disabled');
    document.getElementById("button").disabled=false;
    document.getElementById("button1").disabled=true;
}
function buttonClick1(){
    document.getElementById('td1').removeAttribute('disabled')
    document.getElementById('td2').removeAttribute('disabled')
    document.getElementById('td3').removeAttribute('disabled')
    document.getElementById('td4').removeAttribute('disabled')
    document.getElementById('td5').removeAttribute('disabled')
    document.getElementById('td6').removeAttribute('disabled')
    document.getElementById('td7').removeAttribute('disabled')
    document.getElementById('td8').removeAttribute('disabled')
    document.getElementById("button3").disabled=false;
    document.getElementById('button2').setAttribute('disabled', 'disabled');


}

function baocun1() {
    document.getElementById('td1').setAttribute('disabled', 'disabled');
    document.getElementById('td2').setAttribute('disabled', 'disabled');
    document.getElementById('td3').setAttribute('disabled', 'disabled');
    document.getElementById('td4').setAttribute('disabled', 'disabled');
    document.getElementById('td5').setAttribute('disabled', 'disabled');
    document.getElementById('td6').setAttribute('disabled', 'disabled');
    document.getElementById('td7').setAttribute('disabled', 'disabled');
    document.getElementById('td8').setAttribute('disabled', 'disabled');
    document.getElementById("button2").disabled=false;
    document.getElementById("button3").disabled=true;
}

function buttonClick2(){
    document.getElementById('step1').removeAttribute('disabled')
    document.getElementById("button5").disabled=false;
    document.getElementById('button4').setAttribute('disabled', 'disabled');
}

function baocun2() {
    document.getElementById('step1').setAttribute('disabled', 'disabled');
    document.getElementById("button4").disabled=false;
    document.getElementById("button5").disabled=true;
}

function buttonClick3(){
    document.getElementById('step2').removeAttribute('disabled')
    document.getElementById("button7").disabled=false;
    document.getElementById('button6').setAttribute('disabled', 'disabled');
}

function baocun3() {
    document.getElementById('step2').setAttribute('disabled', 'disabled');
    document.getElementById("button6").disabled=false;
    document.getElementById("button7").disabled=true;
}

function buttonClick4(){
    document.getElementById('step3').removeAttribute('disabled')
    document.getElementById("button9").disabled=false;
    document.getElementById('button8').setAttribute('disabled', 'disabled');
}

function baocun4() {
    document.getElementById('step3').setAttribute('disabled', 'disabled');
    document.getElementById("button8").disabled=false;
    document.getElementById("button9").disabled=true;
}

function buttonClick5(){
    document.getElementById('yg1').removeAttribute('disabled')
    document.getElementById('yg2').removeAttribute('disabled')
    document.getElementById('yg3').removeAttribute('disabled')
    document.getElementById('yg4').removeAttribute('disabled')
    document.getElementById('yg5').removeAttribute('disabled')
    document.getElementById('yg6').removeAttribute('disabled')
    document.getElementById('yg7').removeAttribute('disabled')
    document.getElementById('yg8').removeAttribute('disabled')
    document.getElementById('yg9').removeAttribute('disabled')
    document.getElementById('yg10').removeAttribute('disabled')
    document.getElementById('yg11').removeAttribute('disabled')
    document.getElementById('yg12').removeAttribute('disabled')
    document.getElementById('yg13').removeAttribute('disabled')
    document.getElementById("button11").disabled=false;
    document.getElementById('button10').setAttribute('disabled', 'disabled');


}

function baocun5() {
    document.getElementById('yg1').setAttribute('disabled', 'disabled');
    document.getElementById('yg2').setAttribute('disabled', 'disabled');
    document.getElementById('yg3').setAttribute('disabled', 'disabled');
    document.getElementById('yg4').setAttribute('disabled', 'disabled');
    document.getElementById('yg5').setAttribute('disabled', 'disabled');
    document.getElementById('yg6').setAttribute('disabled', 'disabled');
    document.getElementById('yg7').setAttribute('disabled', 'disabled');
    document.getElementById('yg8').setAttribute('disabled', 'disabled');
    document.getElementById('yg9').setAttribute('disabled', 'disabled');
    document.getElementById('yg10').setAttribute('disabled', 'disabled');
    document.getElementById('yg11').setAttribute('disabled', 'disabled');
    document.getElementById('yg12').setAttribute('disabled', 'disabled');
    document.getElementById('yg13').setAttribute('disabled', 'disabled');
    document.getElementById("button10").disabled=false;
    document.getElementById("button11").disabled=true;
}
$(function(){

    $('.circlechart').circlechart();

});

function buttonClick6(){
    document.getElementById('yl1').removeAttribute('disabled')
    document.getElementById("btn2").disabled=false;
    document.getElementById('btn1').setAttribute('disabled', 'disabled');
}

function baocun6() {
    document.getElementById('yl1').setAttribute('disabled', 'disabled');
    document.getElementById("btn1").disabled=false;
    document.getElementById("btn2").disabled=true;
}

function buttonClick7(){
    document.getElementById('yl2').removeAttribute('disabled')
    document.getElementById("btn4").disabled=false;
    document.getElementById('btn3').setAttribute('disabled', 'disabled');
}

function baocun7() {
    document.getElementById('yl2').setAttribute('disabled', 'disabled');
    document.getElementById("btn3").disabled=false;
    document.getElementById("btn4").disabled=true;
}

function buttonClick8(){
    document.getElementById('yl3').removeAttribute('disabled')
    document.getElementById("btn6").disabled=false;
    document.getElementById('btn5').setAttribute('disabled', 'disabled');
}

function baocun8() {
    document.getElementById('yl3').setAttribute('disabled', 'disabled');
    document.getElementById("btn5").disabled=false;
    document.getElementById("btn6").disabled=true;
}

function buttonClick9(){
    document.getElementById('yl4').removeAttribute('disabled')
    document.getElementById("btn8").disabled=false;
    document.getElementById('btn7').setAttribute('disabled', 'disabled');
}

function baocun9() {
    document.getElementById('yl4').setAttribute('disabled', 'disabled');
    document.getElementById("btn7").disabled=false;
    document.getElementById("btn8").disabled=true;
}



